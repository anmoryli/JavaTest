package com.anmory;

/**
 * @author Anmory/李梦杰
 * @description TODO
 * @date 2025-04-27 下午4:09
 */

public class Robot implements People{
    @Override
    public void create() {
        System.out.println("我是机器人");
    }
}
