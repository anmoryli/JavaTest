package com.anmory;

/**
 * @author Anmory/李梦杰
 * @description TODO
 * @date 2025-04-27 下午5:51
 */

public abstract class ImageReaderFactory {
    public abstract ImageReader getImageReader();
}
