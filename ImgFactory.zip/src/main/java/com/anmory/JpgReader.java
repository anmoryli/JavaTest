package com.anmory;

/**
 * @author Anmory/李梦杰
 * @description TODO
 * @date 2025-04-27 下午6:13
 */

public class JpgReader extends ImageReader {
    @Override
    public void readImg() {
        System.out.println("jpg图片读取成功");
    }
}
