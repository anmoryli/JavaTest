package com.anmory;

/**
 * @author Anmory/李梦杰
 * @description TODO
 * @date 2025-04-27 下午6:11
 */

public class GifReader extends ImageReader{
    @Override
    public void readImg() {
        System.out.println("gif图片读取成功");
    }
}
