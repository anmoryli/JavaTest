package com.anmory;

/**
 * @author Anmory/李梦杰
 * @description TODO
 * @date 2025-04-27 下午6:10
 */

public abstract class ImageReader {
    public abstract void readImg();
}
