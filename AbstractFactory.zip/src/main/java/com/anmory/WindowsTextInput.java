package com.anmory;

/**
 * @author Anmory
 * @description TODO
 * @date 2025-05-12 下午4:09
 */

public class WindowsTextInput extends TextInput{
    @Override
    public void render() {
        System.out.println("Windows文本框输入文本");
    }
}
