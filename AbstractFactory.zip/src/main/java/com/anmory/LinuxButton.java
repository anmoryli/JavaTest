package com.anmory;

/**
 * @author Anmory
 * @description TODO
 * @date 2025-05-12 下午4:08
 */

public class LinuxButton extends Button{
    @Override
    public void click() {
        System.out.println("Linux 按钮被点击");
    }
}
