package com.anmory;

/**
 * @author Anmory
 * @description TODO
 * @date 2025-05-12 下午4:07
 */

public abstract class Button {
    public abstract void click();
}
