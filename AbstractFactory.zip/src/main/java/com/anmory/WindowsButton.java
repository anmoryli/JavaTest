package com.anmory;

/**
 * @author Anmory
 * @description TODO
 * @date 2025-05-12 下午4:08
 */

public class WindowsButton extends Button{
    @Override
    public void click() {
        System.out.println("Windows 按钮被点击");
    }
}
