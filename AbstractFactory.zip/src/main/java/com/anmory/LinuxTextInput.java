package com.anmory;

/**
 * @author Anmory
 * @description TODO
 * @date 2025-05-12 下午4:10
 */

public class LinuxTextInput extends TextInput{
    @Override
    public void render() {
        System.out.println("Linux文本框输入文本");
    }
}
