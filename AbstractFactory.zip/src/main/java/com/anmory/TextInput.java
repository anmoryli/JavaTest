package com.anmory;

/**
 * @author Anmory
 * @description TODO
 * @date 2025-05-12 下午4:09
 */

public abstract class TextInput {
    public abstract void render();
}
