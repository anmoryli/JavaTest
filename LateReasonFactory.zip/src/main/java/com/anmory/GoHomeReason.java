package com.anmory;

/**
 * @author Anmory/李梦杰
 * @description TODO
 * @date 2025-04-28 下午3:54
 */

public class GoHomeReason extends LateReason{
    @Override
    public void getLateReason() {
        System.out.println("回家迟到");
    }
}
