package com.anmory;

/**
 * @author Anmory/李梦杰
 * @description TODO
 * @date 2025-04-28 下午3:59
 */

public abstract class LateReasonFactory {
    public abstract LateReason getLateReason();
}
