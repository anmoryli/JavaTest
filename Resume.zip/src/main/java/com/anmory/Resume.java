package com.anmory;

/**
 * @author Anmory
 * @description TODO
 * @date 2025-05-12 下午7:25
 */

public abstract class Resume {
    abstract String getName();
    abstract String getDescription();
}
